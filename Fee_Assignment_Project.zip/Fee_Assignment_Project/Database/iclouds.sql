-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2022 at 05:17 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iclouds`
--

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` int(11) NOT NULL,
  `Branch Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `Branch Name`) VALUES
(0, 'Branch Name'),
(1, 'Branch Name'),
(2, 'Branch Name'),
(3, 'Branch Name');

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `id` int(11) NOT NULL,
  `Branch name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`id`, `Branch name`) VALUES
(0, 'Branch Name'),
(1, 'School of Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `common_fee_collection`
--

CREATE TABLE `common_fee_collection` (
  `id` int(11) NOT NULL,
  `moduleid` int(100) NOT NULL,
  `tranid` int(100) NOT NULL,
  `admno` varchar(100) NOT NULL,
  `rollno` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `brid` int(100) NOT NULL,
  `academicYear` varchar(100) NOT NULL,
  `financialYear` varchar(100) NOT NULL,
  `displayReceiptNo` varchar(100) NOT NULL,
  `EntryMode` int(100) NOT NULL,
  `paidDate` date NOT NULL,
  `inactive` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `common_fee_collection`
--

INSERT INTO `common_fee_collection` (`id`, `moduleid`, `tranid`, `admno`, `rollno`, `amount`, `brid`, `academicYear`, `financialYear`, `displayReceiptNo`, `EntryMode`, `paidDate`, `inactive`) VALUES
(534873, 1, 668214, '20GCFC1030009', '3171T020CUGCFC101N003', '97000.00', 1, '2016-2017', '2016-2017', '2020-2021/AIE/C13/2169', 0, '2020-08-28', 'Either 0/1 based \r\non entry and rev \r\nentry \r\nrespectively');

-- --------------------------------------------------------

--
-- Table structure for table `common_fee_collection_headwise`
--

CREATE TABLE `common_fee_collection_headwise` (
  `id` int(11) NOT NULL,
  `moduleid` int(100) NOT NULL,
  `receiptId` int(100) NOT NULL,
  `headId` int(100) NOT NULL,
  `headName` varchar(100) NOT NULL,
  `brid` int(100) NOT NULL,
  `amount` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `common_fee_collection_headwise`
--

INSERT INTO `common_fee_collection_headwise` (`id`, `moduleid`, `receiptId`, `headId`, `headName`, `brid`, `amount`) VALUES
(0, 1, 534873, 3026, 'Tution Fee', 1, '87000.00'),
(1086394, 1, 534873, 3027, 'Exam Fee', 1, '10000.00');

-- --------------------------------------------------------

--
-- Table structure for table `feecategory`
--

CREATE TABLE `feecategory` (
  `id` int(11) NOT NULL,
  `fee_category` text NOT NULL,
  `br_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feecategory`
--

INSERT INTO `feecategory` (`id`, `fee_category`, `br_id`) VALUES
(1, 'general', 30);

-- --------------------------------------------------------

--
-- Table structure for table `financial_trans`
--

CREATE TABLE `financial_trans` (
  `id` int(11) NOT NULL,
  `moduleid` int(100) NOT NULL,
  `tranid` int(100) NOT NULL,
  `admno` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `crdr` varchar(100) NOT NULL,
  `tranDate` date NOT NULL,
  `acadYear` varchar(100) NOT NULL,
  `Entrymode` varchar(100) NOT NULL,
  `voucherno` int(100) NOT NULL,
  `brid` int(100) NOT NULL,
  `Typeofconsession` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `financial_trans`
--

INSERT INTO `financial_trans` (`id`, `moduleid`, `tranid`, `admno`, `amount`, `crdr`, `tranDate`, `acadYear`, `Entrymode`, `voucherno`, `brid`, `Typeofconsession`) VALUES
(252026, 1, 736331, '11CETBT101146', '138000.00', 'D', '2011-08-01', '2011-2012', '0', 576499, 1, 'Either 1 or 2\r\nbased on\r\nentry');

-- --------------------------------------------------------

--
-- Table structure for table `financial_transdetail`
--

CREATE TABLE `financial_transdetail` (
  `id` int(11) NOT NULL,
  `financialTranid` varchar(100) NOT NULL,
  `moduleid` int(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `headid` int(100) NOT NULL,
  `crdr` varchar(100) NOT NULL,
  `brid` int(100) NOT NULL,
  `head_name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `financial_transdetail`
--

INSERT INTO `financial_transdetail` (`id`, `financialTranid`, `moduleid`, `amount`, `headid`, `crdr`, `brid`, `head_name`) VALUES
(656280, '252026', 1, '128000.00', 3024, 'D', 30, 'Tution Fee'),
(656281, '252026', 1, '10000.000', 3025, 'D', 30, 'Security Fee');

-- --------------------------------------------------------

--
-- Table structure for table `report1`
--

CREATE TABLE `report1` (
  `admno` varchar(100) NOT NULL,
  `rollno` varchar(100) NOT NULL,
  `receiptno` varchar(100) NOT NULL,
  `receiptdate` varchar(100) NOT NULL,
  `academicyear` varchar(100) NOT NULL,
  `dueamount` varchar(100) DEFAULT NULL,
  `paidamount` varchar(100) NOT NULL,
  `concessionamount` varchar(100) DEFAULT NULL,
  `scholarshipamount` varchar(100) DEFAULT NULL,
  `reverseconsessionamount` varchar(100) NOT NULL,
  `writeoffamount` varchar(100) DEFAULT NULL,
  `adjustedamount` varchar(100) DEFAULT NULL,
  `refundamount` varchar(100) DEFAULT NULL,
  `fundtransferamount` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report1`
--

INSERT INTO `report1` (`admno`, `rollno`, `receiptno`, `receiptdate`, `academicyear`, `dueamount`, `paidamount`, `concessionamount`, `scholarshipamount`, `reverseconsessionamount`, `writeoffamount`, `adjustedamount`, `refundamount`, `fundtransferamount`) VALUES
('001', 'RS01', '161656', '12.02.2021', '2016-2017', NULL, '2000.00', NULL, NULL, '100.00', NULL, NULL, NULL, NULL),
('001', 'RS01', '161656', '12.2.2021', '2016-2017', NULL, '2000.00', NULL, NULL, '', NULL, NULL, NULL, NULL),
('002', 'RS02', '142563', '14.2.2021', '2016-2017', NULL, '', NULL, NULL, '100', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `report2`
--

CREATE TABLE `report2` (
  `admno` varchar(11) NOT NULL,
  `rollno` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `receiptno` varchar(100) NOT NULL,
  `receiptdate` varchar(100) NOT NULL,
  `academicyear` varchar(100) NOT NULL,
  `tuitionfee` varchar(100) NOT NULL,
  `examfee` varchar(100) DEFAULT NULL,
  `libraryfee` varchar(100) DEFAULT NULL,
  `sportsfee` varchar(100) DEFAULT NULL,
  `degreefee` varchar(100) DEFAULT NULL,
  `otherfee` varchar(100) DEFAULT NULL,
  `miscfee` varchar(100) DEFAULT NULL,
  `convocationfee` varchar(100) DEFAULT NULL,
  `finefee` varchar(100) DEFAULT NULL,
  `vouchertype` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report2`
--

INSERT INTO `report2` (`admno`, `rollno`, `amount`, `receiptno`, `receiptdate`, `academicyear`, `tuitionfee`, `examfee`, `libraryfee`, `sportsfee`, `degreefee`, `otherfee`, `miscfee`, `convocationfee`, `finefee`, `vouchertype`) VALUES
('001', 'RS01', '2000.00', '161656', '12.02.2021', '2016-2017', '1000.00', NULL, NULL, NULL, '1000.00', NULL, NULL, NULL, NULL, NULL),
('002', 'RS02', '1400.00', '142563', '14.02.2021', '2016-2017', '', NULL, '1200.00', NULL, NULL, '200.00', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `common_fee_collection`
--
ALTER TABLE `common_fee_collection`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `financial_trans`
--
ALTER TABLE `financial_trans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `financial_transdetail`
--
ALTER TABLE `financial_transdetail`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `common_fee_collection`
--
ALTER TABLE `common_fee_collection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=534874;

--
-- AUTO_INCREMENT for table `financial_trans`
--
ALTER TABLE `financial_trans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=252027;

--
-- AUTO_INCREMENT for table `financial_transdetail`
--
ALTER TABLE `financial_transdetail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=656282;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
