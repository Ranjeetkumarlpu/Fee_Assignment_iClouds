<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    background:lightgreen;
    text-align:center;
    
    
    
}
table{
    width:450px;
}
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 35px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
</style>
</head>
<center><h1>Welcome To Fee Assignment</h1></center>
<body>

<a href="index.php" target="_blank">Home</a>
<a href="fee.php" target="_blank">Back</a>
<h1>Report 1 </h1>
<center>

<?php


// Create connection
$connection=mysqli_connect("localhost","root","","iclouds");
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$mysql = "SELECT admno, rollno, receiptno ,receiptdate, academicyear, dueamount,paidamount,	concessionamount,scholarshipamount,reverseconsessionamount,writeoffamount,adjustedamount,refundamount,	fundtransferamount FROM report1";

$result = $connection->query($mysql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>Adm no</th>
    <th>Roll no</th>
    <th>Receipt no</th>
    <th>Receipt Date</th>
    <th>Academic Year</th>
    <th>Due Amount</th>
    <th>Paid Amount</th>
    <th>Concession Amount</th>
    <th>Scholarship Amounte</th>
    <th>Reverse Consession Amount</th>
    <th>WriteOff Amount</th>
    <th>Adjusted Amount</th>
    <th>Refund Amount</th>
    <th>Fundtransfer Amount</th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["admno"]. " </td>
         <td>" . $row["rollno"]. " </td>
          <td>" . $row["receiptno"]. " </td>
           <td>" . $row["receiptdate"]. " </td>
           <td>" . $row["academicyear"]. " </td>
         <td>" . $row["dueamount"]. " </td>
          <td>" . $row["paidamount"]. " </td>
           <td>" . $row["concessionamount"]. " </td>
           <td>" . $row["scholarshipamount"]. " </td>
           <td>" . $row["reverseconsessionamount"]. " </td>
         <td>" . $row["writeoffamount"]. " </td>
          <td>" . $row["adjustedamount"]. " </td>
           <td>" . $row["refundamount"]. " </td>
           <td>" . $row["fundtransferamount"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
?>
</center>
<h1>Report 02 </h1>
<center>

<?php


// Create connection
$connection=mysqli_connect("localhost","root","","iclouds");
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$mysql = "SELECT admno, rollno, amount,receiptno, receiptdate, academicyear, tuitionfee,examfee,libraryfee , sportsfee, degreefee, otherfee,miscfee,convocationfee,finefee,vouchertype FROM  report2";

$result = $connection->query($mysql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>Admno</th>
    <th>Roll no</th>
    <th>Amount</th>
    <th>Receipt no</th>
    <th>Receipt Date</th>
    <th>Academic Year</th>
    <th>Tuition Fee</th>
    <th>Exam Fee </th>
    <th>Library Fee</th>
    <th>Sports Fee</th>
    <th>Degree Fee</th>
    <th>other Fee</th>
    <th>Misc Fee</th>
    <th>Convocation Fee</th>
    <th>Fine Fee</th>
    <th>Voucher Type</th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["admno"]. " </td>
         <td>" . $row["rollno"]. " </td>
          <td>" . $row["amount"]. " </td>
           <td>" . $row["receiptno"]. " </td>
           <td>" . $row["receiptdate"]. " </td>
         <td>" . $row["academicyear"]. " </td>
          <td>" . $row["tuitionfee"]. " </td>
           <td>" . $row["examfee"]. " </td>
           <td>" . $row["libraryfee"]. " </td>
           <td>" . $row["sportsfee"]. " </td>
          <td>" . $row["degreefee"]. " </td>
           <td>" . $row["otherfee"]. " </td>
           <td>" . $row["miscfee"]. " </td>
           <td>" . $row["convocationfee"]. " </td>
          <td>" . $row["finefee"]. " </td>
           <td>" . $row["vouchertype"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
?>
</center>

</body>
By: Ranjeet Kumar<br>
E-mail:ranjeetkumarlpu@gmail.com<br>
Mobile:7004129518
</html>