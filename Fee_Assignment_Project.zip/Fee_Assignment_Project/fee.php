<html>
    <title>Fee Assignment</title>
    <head>
        <style>
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 35px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
center{
    padding-top:100px;
}
        </style>
</head>

    <body>
    <a href="index.php" target="_blank">Home</a>
        <center>
        <h1>Welcome To Fee Assignment</h1>
    <a href="registration.php">Payment Now</a>
    <a href="display.php">Display Fee Details-1</a><br><br>
    <a href="report.php">Report  Now</a>
    <a href="display1.php">Display Fee Details-2</a>
   
</center>
</body>
By: Ranjeet Kumar<br>
E-mail:ranjeetkumarlpu@gmail.com<br>
Mobile:7004129518
</html>