<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 2px solid black;
    background:lightgreen;
    text-align:center;
    
    
    
}
table{
    width:450px;
}
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 35px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
</style>
</head>
<center><h1>Welcome To Fee Assignment</h1></center>
<body>
<a href="index.php" target="_blank">Home</a>
<a href="fee.php" target="_blank">Back</a>
<center>

<h2>Common_fee_collection (Parent Table)</h2>
<?php


// Create connection
$connection=mysqli_connect("localhost","root","","iclouds");
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$mysql = "SELECT id, moduleid, tranid,admno,rollno, amount, brid, academicYear, financialYear, displayReceiptNo, EntryMode,paidDate,inactive FROM common_fee_collection";

$result = $connection->query($mysql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>ID</th>
    <th>Module Id</th>
    <th>Tran Id</th>
    <th>Admno</th>
    <th>Rollno</th>
    <th>Amount</th>
    <th>Brid</th>
    <th>Academic Year </th>
    <th>Financial Year</th>
    <th>Display Receipt No</th>
    <th>Entry Mode</th>
    <th>paid Date</th>
    <th>Inactive </th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["id"]. " </td>
         <td>" . $row["moduleid"]. " </td>
          <td>" . $row["tranid"]. " </td>
           <td>" . $row["admno"]. " </td>
           <td>" . $row["rollno"]. " </td>
         <td>" . $row["amount"]. " </td>
          <td>" . $row["brid"]. " </td>
           <td>" . $row["academicYear"]. " </td>
           <td>" . $row["financialYear"]. " </td>
           <td>" . $row["displayReceiptNo"]. " </td>
          <td>" . $row["EntryMode"]. " </td>
           <td>" . $row["paidDate"]. " </td>
           <td>" . $row["inactive"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
?>
</center>
<center>
<h2>Common_fee_collection_headwise (Child Table)</h2>
<?php


// Create connection
$connection=mysqli_connect("localhost","root","","iclouds");
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$mysql = "SELECT id,moduleid, receiptId ,headId, headName,brid,amount FROM common_fee_collection_headwise";

$result = $connection->query($mysql);

if ($result->num_rows > 0) {
    echo "<table><tr>
    <th>ID</th>
    <th>Module Id</th>
    <th>Receipt Id </th>
    <th>Head Id</th>
    <th>Head Name</th>
    <th>Br Id</th>
    <th>Amount </th>
    </tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr>
        <td>" . $row["id"]. " </td>
         <td>" . $row["moduleid"]. " </td>
          <td>" . $row["receiptId"]. " </td>
          <td>" . $row["headId"]. " </td>
         <td>" . $row["headName"]. " </td>
          <td>" . $row["brid"]. " </td>
          <td>" . $row["amount"]. " </td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
?>
</center>

</body>
By: Ranjeet Kumar<br>
E-mail:ranjeetkumarlpu@gmail.com<br>
Mobile:7004129518
</html>