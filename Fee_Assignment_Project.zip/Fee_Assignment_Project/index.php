<html>
    <head>
        <title>Fee Assignment System </title>

<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
a:link, a:visited {
  background-color: #f44336;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}
center{
  padding-top:70px;
}
</style>
</head>
<center><h1>Welcome To Fee Assignment</h1></center>
<body>
    <center>
    <div class="container">
<form action="http://localhost/phpmyadmin/index.php?route=/database/import&db=fee_assignment">
  <label for="myfile">Excel files:</label>
  <input type="file" id="myfile" name="myfile" multiple><br><br>
  
<input type="submit" class="button" value="Import">
 
  </div
</form>
</center>
<a href="fee.php" target="_blank">Fee Details</a>
</body>
<BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
By: Ranjeet Kumar<br>
E-mail:ranjeetkumarlpu@gmail.com<br>
Mobile:7004129518
</html>